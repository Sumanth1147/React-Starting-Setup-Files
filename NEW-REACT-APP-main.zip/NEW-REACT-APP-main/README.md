# NEW-REACT-APP
This Repository contains all the Packages and dependencies required to install a new React app

Step 1: npx create-react-app filename
Step 2: Download this repository and extract the file.
Step 3: Open in Vs code and run npm install(node modules).
Step 4: Install any other dependencies required.
Step 5: run npm start.
